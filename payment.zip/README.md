# PayDash — Payment Dashboard Frontend

> Angular 18 frontend for the Simple Payment Dashboard technical challenge.  
> Built following Clean Architecture, SOLID principles, and Angular best practices.

![Angular](https://img.shields.io/badge/Angular-18-dd0031?style=flat-square&logo=angular)
![TypeScript](https://img.shields.io/badge/TypeScript-5.4-3178c6?style=flat-square&logo=typescript)
![RxJS](https://img.shields.io/badge/RxJS-7.8-b7178c?style=flat-square&logo=reactivex)
![Tests](https://img.shields.io/badge/Tests-Jasmine%20%2B%20Karma-8a4182?style=flat-square)

---

## Table of Contents

1. [Tech Stack](#tech-stack)
2. [Architecture Overview](#architecture-overview)
3. [Project Structure](#project-structure)
4. [Getting Started](#getting-started)
5. [Available Scripts](#available-scripts)
6. [Design Decisions](#design-decisions)
7. [State Management](#state-management)
8. [API Integration](#api-integration)
9. [Testing Strategy](#testing-strategy)
10. [Environment Configuration](#environment-configuration)

---

## Tech Stack

| Technology       | Version | Purpose                            |
|------------------|---------|------------------------------------|
| Angular          | 18.x    | Core framework (standalone APIs)   |
| TypeScript       | 5.4.x   | Type safety throughout             |
| RxJS             | 7.8.x   | Reactive state with BehaviorSubject|
| Angular Reactive Forms | 18.x | Form handling & validation       |
| SCSS             | -       | Component styling                  |
| Jasmine + Karma  | 5.x / 6.x | Unit testing                    |

---

## Architecture Overview

The project follows a **Feature-based Clean Architecture** with clear separation of concerns:

```
Presentation Layer  →  Feature Components (Smart + Dumb)
Business Layer      →  Facade Services, State Services
Data Layer          →  API Services, HTTP Interceptors
Domain Layer        →  Models, Constants, Utilities
```

### Key Principles Applied

- **Single Responsibility**: Each class has one reason to change.
- **Open/Closed**: Interceptors and pipes are composable without modifying core logic.
- **Dependency Inversion**: Components depend on abstractions (services/facades), not concrete HTTP logic.
- **Facade Pattern**: Feature facades (`PaymentFacadeService`, `TransactionFacadeService`) decouple UI components from state and API concerns.
- **OnPush Change Detection**: All components use `ChangeDetectionStrategy.OnPush` for optimal performance.
- **Standalone Components**: No NgModules — 100% standalone API for tree-shaking and lazy loading.

---

## Project Structure

```
src/
├── app/
│   ├── core/                          # Cross-cutting concerns
│   │   ├── interceptors/
│   │   │   ├── http-error.interceptor.ts    # Centralized error handling
│   │   │   └── http-loading.interceptor.ts  # Global loading state
│   │   ├── models/
│   │   │   ├── transaction.model.ts         # Domain entities & types
│   │   │   ├── payment.model.ts             # Request/Response DTOs
│   │   │   └── api-endpoints.const.ts       # API path constants
│   │   └── services/
│   │       ├── payment-api.service.ts       # HTTP layer
│   │       ├── notification.service.ts      # Toast notifications state
│   │       ├── loading.service.ts           # Global loading state
│   │       └── transaction-state.service.ts # BehaviorSubject state
│   │
│   ├── features/                      # Feature modules
│   │   ├── payment/
│   │   │   ├── components/
│   │   │   │   └── payment-form/      # Virtual POS form
│   │   │   └── services/
│   │   │       └── payment-facade.service.ts
│   │   └── transactions/
│   │       ├── components/
│   │       │   └── transaction-table/ # History table
│   │       └── services/
│   │           └── transaction-facade.service.ts
│   │
│   ├── shared/                        # Reusable, feature-agnostic
│   │   ├── components/
│   │   │   └── notification/          # Toast component
│   │   ├── pipes/
│   │   │   └── app-currency.pipe.ts   # Currency formatting
│   │   └── utils/
│   │       └── card.utils.ts          # Luhn validation, masking, formatting
│   │
│   ├── dashboard.component.ts         # Root page (Smart component)
│   ├── app.component.ts               # App shell
│   ├── app.routes.ts                  # Lazy-loaded routes
│   └── app.config.ts                  # Application providers
│
├── environments/
│   ├── environment.ts                 # Development config
│   └── environment.production.ts     # Production config
├── styles.scss                        # Global design tokens + reset
└── main.ts                            # Bootstrap entry point
```

---

## Getting Started

### Prerequisites

- **Node.js** >= 20.x
- **npm** >= 9.x
- **Angular CLI** >= 18.x

```bash
npm install -g @angular/cli@18
```

### Installation

```bash
# 1. Clone or extract the project
cd payment-dashboard

# 2. Install dependencies
npm install

# 3. Configure the API URL (default: http://localhost:8000)
# Edit src/environments/environment.ts if needed

# 4. Start the development server
npm start
```

The app will be available at `http://localhost:4200`

> **Note:** Make sure the Backend API is running at `http://localhost:8000` before starting the frontend.

---

## Available Scripts

```bash
# Development server (with hot reload)
npm start

# Production build
npm run build:prod

# Run unit tests (headless)
npm test

# Run tests with coverage report
npm run test:coverage

# Lint the project
npm run lint
```

---

## Design Decisions

### Why BehaviorSubject over NgRx?

For an application of this scope, NgRx adds boilerplate without significant benefit. `BehaviorSubject` in `TransactionStateService` provides:
- Synchronous access to the current state via `.getValue()`
- Observable streams for reactive UI updates
- Simple patching with private `patchState()` method
- Easy testability with simple unit tests

### Standalone Components & Lazy Loading

All components are standalone (`standalone: true`), and the main dashboard page is lazy-loaded via `loadComponent()`. This eliminates NgModule boilerplate and improves initial bundle size.

### Facade Pattern

Feature facades (`PaymentFacadeService`, `TransactionFacadeService`) act as the bridge between the presentation layer and business/data layers:
- Components only know about the facade, not the API service or state service
- Easier to test components in isolation by mocking only the facade
- Business logic lives in the facade, not the component

### HTTP Interceptors

Two functional interceptors (Angular 18 `HttpInterceptorFn`):
1. **`httpLoadingInterceptor`** — Automatically manages the loading counter for any HTTP request
2. **`httpErrorInterceptor`** — Centralizes error handling and shows user-friendly toast notifications

---

## State Management

State is managed via `TransactionStateService` using RxJS `BehaviorSubject`:

```typescript
interface TransactionState {
  transactions: Transaction[];   // Full history list
  isLoading: boolean;            // HTTP in-flight indicator
  error: string | null;          // Last error message
  lastProcessed: Transaction | null; // Most recent payment result
}
```

Components subscribe to `state$` or derived observables for reactive rendering. The `DashboardComponent` connects `PaymentFormComponent` (writes) to `TransactionTableComponent` (reads) through the shared state.

---

## API Integration

Configured via `src/environments/environment.ts`:

```typescript
export const environment = {
  apiBaseUrl: 'http://localhost:8000',
};
```

### Endpoints Used

| Method | URL | Description |
|--------|-----|-------------|
| `POST` | `/payments` | Process a new payment |
| `GET`  | `/payments` | Retrieve transaction history |

### Expected Request Body (POST /payments)

```json
{
  "amount": 150.75,
  "currency": "USD",
  "cardNumber": "4111111111111112",
  "cardHolder": "JOHN DOE"
}
```

### Expected Response (POST /payments)

```json
{
  "transaction": {
    "id": "uuid-here",
    "amount": 150.75,
    "currency": "USD",
    "cardHolder": "JOHN DOE",
    "cardNumber": "4111111111111112",
    "status": "APPROVED",
    "createdAt": "2025-01-01T12:00:00Z"
  },
  "message": "Transaction approved."
}
```

---

## Testing Strategy

Unit tests are written with **Jasmine** and run via **Karma**.

### What is tested

| File | Coverage Focus |
|------|----------------|
| `notification.service.spec.ts` | Add/dismiss, auto-dismiss timer, multiple notifications |
| `transaction-state.service.spec.ts` | State mutations: set, patch, reset, prepend |
| `payment-api.service.spec.ts` | HTTP calls, endpoints, request bodies (using `HttpTestingController`) |
| `card.utils.spec.ts` | Luhn validation, masking, formatting, brand detection |
| `app-currency.pipe.spec.ts` | Currency formatting per locale and edge cases |

### Running tests

```bash
# Interactive browser mode
npm test

# With coverage report (generated in /coverage/payment-dashboard)
npm run test:coverage
```

---

## Environment Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `apiBaseUrl` | `http://localhost:8000` | Backend API base URL |
| `production` | `false` | Enables production optimizations |
| `appName` | `PayDash` | Application display name |
| `version` | `1.0.0` | App version |
