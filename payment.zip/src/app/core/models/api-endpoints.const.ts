export const API_ENDPOINTS = {
  PAYMENTS: {
    PROCESS: '/api/v1/transactions',
    HISTORY: '/api/v1/transactions',
  },
} as const;
