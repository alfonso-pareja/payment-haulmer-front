import { Injectable, inject } from '@angular/core';
import { delay, firstValueFrom, Observable, tap } from 'rxjs';
import { PaymentApiService } from '@core/services/payment-api.service';
import { TransactionStateService } from '@core/services/transaction-state.service';
import { PaymentResultService } from '@shared/components/payment-result-modal/payment-result.service';
import { PaymentRequest, PaymentResponse } from '@core/models/payment.model';

@Injectable({ providedIn: 'root' })
export class PaymentFacadeService {
  private readonly api    = inject(PaymentApiService);
  private readonly state  = inject(TransactionStateService);
  private readonly modal  = inject(PaymentResultService);

  processPayment(request: PaymentRequest): Observable<PaymentResponse> {
    this.modal.startProcessing();
    this.state.isLoading.set(true);

    // Small delay so the loader is visible
    return this.api.processPayment(request).pipe(
      delay(800),
      tap({
        next: (response) => {
          this.state.addTransaction(response.transaction);
          this.state.isLoading.set(false);
          this.modal.showResult(response.transaction);
        },
        error: () => {
          this.state.isLoading.set(false);
          this.modal.close();
        },
      })
    )

    // try {
    //   const response = await firstValueFrom(this.api.processPayment(request));
    //   this.state.addTransaction(response.transaction);
    //   this.state.isLoading.set(false);
    //   this.modal.showResult(response.transaction);

    //   return response;
    // } catch (error) {
    //   this.state.isLoading.set(false);
    //   this.modal.close();
    //   throw error;
    // }

  }
}
