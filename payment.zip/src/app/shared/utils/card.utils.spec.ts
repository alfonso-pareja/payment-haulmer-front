import {
  validateCardLuhn,
  maskCardNumber,
  formatCardNumber,
  detectCardBrand,
} from './card.utils';

describe('Card Utilities', () => {

  describe('validateCardLuhn()', () => {
    it('should return true for a valid Visa card number', () => {
      expect(validateCardLuhn('4111111111111111')).toBeTrue();
    });

    it('should return true for a valid Mastercard number', () => {
      expect(validateCardLuhn('5500005555555559')).toBeTrue();
    });

    it('should return false for an invalid card number', () => {
      expect(validateCardLuhn('1234567890123456')).toBeFalse();
    });

    it('should return false for non-numeric input', () => {
      expect(validateCardLuhn('abcd-efgh-ijkl')).toBeFalse();
    });

    it('should handle numbers with spaces', () => {
      expect(validateCardLuhn('4111 1111 1111 1111')).toBeTrue();
    });
  });

  describe('maskCardNumber()', () => {
    it('should mask all but last 4 digits', () => {
      expect(maskCardNumber('4111111111111111')).toBe('**** **** **** 1111');
    });

    it('should handle card numbers with spaces', () => {
      expect(maskCardNumber('4111 1111 1111 1234')).toBe('**** **** **** 1234');
    });
  });

  describe('formatCardNumber()', () => {
    it('should insert spaces every 4 digits', () => {
      expect(formatCardNumber('4111111111111111')).toBe('4111 1111 1111 1111');
    });

    it('should strip non-numeric characters', () => {
      expect(formatCardNumber('4111-1111-1111-1111')).toBe('4111 1111 1111 1111');
    });

    it('should not exceed 19 characters (16 digits + 3 spaces)', () => {
      const result = formatCardNumber('12345678901234567890');
      expect(result.length).toBeLessThanOrEqual(19);
    });

    it('should return partial formatting for incomplete input', () => {
      expect(formatCardNumber('4111')).toBe('4111');
      expect(formatCardNumber('41111111')).toBe('4111 1111');
    });
  });

  describe('detectCardBrand()', () => {
    it('should detect Visa cards (starting with 4)', () => {
      expect(detectCardBrand('4111111111111111')).toBe('visa');
    });

    it('should detect Mastercard (starting with 51-55)', () => {
      expect(detectCardBrand('5500005555555559')).toBe('mastercard');
    });

    it('should detect Amex (starting with 34 or 37)', () => {
      expect(detectCardBrand('371449635398431')).toBe('amex');
      expect(detectCardBrand('341234567890123')).toBe('amex');
    });

    it('should return unknown for unrecognized prefix', () => {
      expect(detectCardBrand('6011111111111117')).toBe('unknown');
    });

    it('should handle formatted input with spaces', () => {
      expect(detectCardBrand('4111 1111 1111 1111')).toBe('visa');
    });
  });

});
