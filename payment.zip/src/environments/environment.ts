export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8000',
  appName: 'PayDash',
  version: '1.0.0',
};
